﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Apocalypse.Dialogs.NewProj
{
    public partial class NewProjPage_Finish : Apocalypse.Dialogs.NewProj.NewProjPageBase
    {
        public NewProjPage_Finish()
        {
            InitializeComponent();
        }
    }
}

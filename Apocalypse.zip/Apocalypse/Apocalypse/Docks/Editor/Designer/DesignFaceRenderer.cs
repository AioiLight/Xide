﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace Apocalypse.Docks.Editor.Designer
{
    public class DesignFaceRenderer
    {
        DesignFace parent;
        public DesignFaceRenderer(DesignFace parent)
        {
            this.parent = parent;
        }

        public void Render(PaintEventArgs e)
        {

        }
    }
}

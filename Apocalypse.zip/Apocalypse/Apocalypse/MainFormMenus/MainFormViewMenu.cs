﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Apocalypse
{
    public partial class MainForm
    {
        private void menuShowGEdit_Click(object sender, EventArgs e)
        {

        }

        private void menuShowSrc_Click(object sender, EventArgs e)
        {

        }

        private void menuShowSlnExp_Click(object sender, EventArgs e)
        {

        }

        private void menuShowProp_Click(object sender, EventArgs e)
        {

        }

        private void menuShowToolbox_Click(object sender, EventArgs e)
        {

        }

        private void menuShowOverview_Click(object sender, EventArgs e)
        {

        }

        //plugin manager
        private void menuShowPMan_Click(object sender, EventArgs e)
        {

        }

        private void menuPrefences_Click(object sender, EventArgs e)
        {

        }
    }
}

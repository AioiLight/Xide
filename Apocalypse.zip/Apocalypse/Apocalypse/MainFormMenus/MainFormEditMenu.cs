﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Apocalypse
{
    public partial class MainForm
    {
        private void menuUndo_Click(object sender, EventArgs e)
        {

        }

        private void menuRedo_Click(object sender, EventArgs e)
        {

        }

        private void menuCut_Click(object sender, EventArgs e)
        {

        }

        private void menuCopy_Click(object sender, EventArgs e)
        {

        }

        private void menuPaste_Click(object sender, EventArgs e)
        {

        }

        private void menuDelete_Click(object sender, EventArgs e)
        {

        }

        private void menuSelectAll_Click(object sender, EventArgs e)
        {

        }
    }
}

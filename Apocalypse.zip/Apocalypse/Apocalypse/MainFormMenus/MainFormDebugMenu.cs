﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Apocalypse
{
    public partial class MainForm
    {
        private void menuTestProj_Click(object sender, EventArgs e)
        {

        }

        private void menuTestMap_Click(object sender, EventArgs e)
        {

        }

        private void menuTestByPos_Click(object sender, EventArgs e)
        {

        }

    }
}
